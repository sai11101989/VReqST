# HistorySphere VR System:

HistorySphere is an open-source educational Virtual Reality (VR) system designed to enhance the learning experience of students studying NCERT History books for grades 8, 9, and 10. It provides an immersive and realistic way for students to explore historical sites and artifacts, allowing them to gain a deeper understanding of history in a dynamic and memorable way.

## Features:

The HistorySphere VR system includes the following features:

1. VR Headset and Controllers: The system includes a VR headset and controllers that provide an immersive and interactive experience for students to explore historical sites and artifacts.

2. HistorySphere Software: The software contains a library of historical sites and artifacts that can be explored in detail. It includes accurate 3D models, audio guides, and interactive features to enhance the learning experience.

3. Companion Resource for NCERT History Books: HistorySphere serves as a companion resource for NCERT History books for grades 8, 9, and 10. It provides a visual and immersive supplement to traditional history lessons, helping students to better understand and appreciate historical concepts.


## JSON File Specifications

The HistorySphere VR system uses several JSON files to store data related to historical sites, articles, actions, customizations, and timelines. Here are the specifications for each file:

1. `scene.json`: This file contains data related to historical sites such as Fort, including their names, descriptions, 3D models, and other properties. It includes an array of objects, with each object representing a historical site and its associated data.

2. `article.json`: This file contains data related to articles that provide additional information about historical sites(fort) or  Articles - Door, Weapon, Artifact, Viewpoint, Banner, Manuscript, Map. It includes an array of objects, with each object representing an article and its associated data, such as title, content, and references.

3. `actres.json`: This file contains data related to actions that can be performed by users/visitors in the VR environment, such as interacting with objects or triggering events. It includes an array of objects, with each object representing an action and its associated response data.

4. `custom.json`: This file contains data related to customizations that users can make in the VR environment, such as implementing conditions like if else or loop like while , for, do-while and switch case according to there usage.

5. `timeline.json`: This file contains data related to timelines that provide a chronological sequence of historical events. It includes an array of objects, with each object representing a timeline event and its associated data, such as  start time and end time.

## Assumption:
- In custom.json, behavior rules are converted into BASE-64 encoding, as code-snippets cannot be saved directly inside a JSON file. The template used is the same as mentioned in the VreqST.
