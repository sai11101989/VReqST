"Be Your Best Football VR" provides users with an immersive and engaging football
training experience using virtual reality technology. The product aims to simulate football games and training sessions to allow users to improve their skills and techniques in a realistic environment. The product is simple and lightweight containing models for the players, ball, goals and scoreboard. The player can interact with the ball or other players to simulate football in the real world and can score goals.





NOTE:

------ARTICLE.JSON------
In the validator dheight is misspelled as dheigth (this is also the case in the example provided on the website). Thus we have also renamed dheight to dheigth so that the validator does not fail.

------TIMELINE.JSON------
Timeline has been created following the format mentioned on the website. The validator provided for timeline does not work for the json (even for the example provided on the website).

------CUSTOM.JSON------
No validator has been provided for custom.json file, so some assumptions have been made.

1) borderasync and bordersync parameters have been assumed to be optional and hence not been used in the json

2) All the parameters have been assumed to be  of type string.

3) The validator mentioned in the website does not work for the json (even for the example provided on the website).

4) The following rules have been used

Rule1:
if( {_gameball $enters _goalpostsetter1} )
then team2_point = team2_point +1

Elf( {_gameball $enters _goalpostsetter2} )
then team1_point = team1_point +1

Rule 2:
if( {_football $touches _hand} AND {_player $outside _penaltyarea})
then $freekick(_opponentplayer)

Rule 3:
if( {_football $outside _goalline} AND {_anyplayer $hits _owngoaline}) AND {_football $outside _goalpost})
then $cornerkick(_opponentplayer)

Rule 4:
if( {_football $outside _goalline} AND {_anyplayer $hits _oponentgoaline}) AND {_football $outside _goalpost})
then $goalkick(_opponentplayer)

Rule 5:
if( {_football $outside _anysideline} AND {_anyplayer $hits _football})
then $throwin(_opponentplayer)

Rule 6:
if( {_player $hits _opponentplayer} AND {_opponentplayer $inside _penaltyarea})
then $penalty(_opponentplayer)

Rule 7:
if( {_player $hits _opponentplayer} AND {_opponentplayer $inside _penaltyarea})
then $freekick(_opponentplayer)

Rule 8:
if( {_football $touches _hand} AND {_player $inside _penaltyarea})
then $penalty(_opponentplayer)

Rule 9:
if( {_time $elapsed 45} 
then $switchsides

Rule 10:
if( {_time $elapsed 90} 
then $matchends





