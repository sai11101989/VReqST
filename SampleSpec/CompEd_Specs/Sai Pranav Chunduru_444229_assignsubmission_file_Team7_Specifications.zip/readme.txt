Our product is a VR tennis game which allows users to play against an AI of various difficulties or against other players.
The multi-player functionality supports online play or playing against others in the same physical space.
The users have the ability to move around via an omni-directional treadmill. They can also control the selection of the shot 
i.e. forehand, backhand, and serve. The app provides a convenient and accessible way for the users to enjoy the game of tennis
regardless of the time, their location or the weather outside. Our app also has a user-friendly interface and high-quality sound and graphics,
and the gameplay is expected to have minimal latency and other technical difficulties.
