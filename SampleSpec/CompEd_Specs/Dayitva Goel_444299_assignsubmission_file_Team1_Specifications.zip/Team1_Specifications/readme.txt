Assignment 3: Requirement Specification

Team: 1
Members:
- Samyak Jain (2019101013)
- Dayitva Goel (2019101005)
- Balaji Venkateshwar (2019111029)
- Rutvij Menavlikar (2019111032)
- Aryan Kharbanda (2019101018)

Product Description:
The VR product proposed is called Lucid which is a platform that can provide fully interactive and immersive experiences to its users. Any kind of experience can be designed in this platform which the user can then experience virtually.

Assumptions made by us:
Lucid describes gives a vague idea of a virtual reality platform and does not specify a product. Hence, we chose the product of a Virtual concert with a performer on the stage and an audience. Here, the audience can interact with themselves, and there will be a virtual snack counter where people can buy snacks for others to increase their happiness points.