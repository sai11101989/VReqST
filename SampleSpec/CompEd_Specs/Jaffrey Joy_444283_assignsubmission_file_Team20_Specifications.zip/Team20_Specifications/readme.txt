The Virtual Reality Library system will provide users access to a virtual 
reality environment to browse and borrow digital content such as books, 
movies, and games. The system will allow users to create an account, 
search and browse for digital content, borrow and return items, rate and 
review content, and receive notifications about due dates and new content. 
The system will also provide library staff with an admin dashboard to 
manage users and digital content and view usage statistics. The 
technology stack for the system will include Unity 3D, C#, and Microsoft 
SQL Server.
