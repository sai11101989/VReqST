The product is a virtual reality shooting range game that simulates the experience of shooting with a variety of firearms. 
The game features both single player and multiplayer modes, with realistic physics and animations to provide an immersive experience. 
The game includes different types of targets, shooting scenarios, and levels to challenge players. 
The game also has a scoring system and leaderboards to motivate players to improve their skills and compete with others. 
The game will be available on different virtual reality platforms and will require compatible VR equipment to play.
The end result is a product that provides a safe and engaging way for users to practice and improve their shooting skills.