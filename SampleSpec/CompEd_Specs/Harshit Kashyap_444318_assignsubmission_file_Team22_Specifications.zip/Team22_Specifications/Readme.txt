# Assignment-3: Requirement Specification  
## Software Engineering

### Product Information

The Car Driving Simulator is a VR based facility where the player an experience which closely mimics the actual experience of driving a car. The simulator have a hardware support for the VR-Headset, Steering wheel and all the pedals. This simulator provides with multiple challenges which a driver faces in day to day life which makes them, to learn driving more perfectly. These situations include weather conditions, road issues, and many environmental experiments so that the user get true experience of driving. Apart from this, it also have a multi player support so that multiple player can engage at a single time.