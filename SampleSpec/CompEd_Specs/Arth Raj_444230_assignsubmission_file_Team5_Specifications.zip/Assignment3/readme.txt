Rule 1:
if( {_user $clicks _menuX}
then $open(in-game)

Rule 2:
if( {_user $looks _displayX}
then $play(_displayX)

Since the SRS mentions a VR Product, we display a simple product specification of VR waiting area in our assignment.