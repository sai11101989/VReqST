# Assignment 3 :VReqSTool

## Team 25

File Description

1. Scene.json
   We have added some new properties too that's why attaching scene_validator.json
2. Article.json
   Describe the types of articles or objects used in the scene.
3. Action_response.json
   Describe the actions performed by or on the articles along with their respective response outcomes.
4. Custom.json
   Describe behavior of the certain article and its action using minimal code constraints.
5. Timeline.json
   Describe the synchronous and asynchronous events in a timeline.

## There are several bugs which we have identified in the tool:

- 'raythinkness' instead of 'raythickness' while validation
- 'dheigth' instead of 'dheight'
- same key i.e. 'type' is used twice in scene.json file
- asyncObjList is showing mandatory while it is optional in validator template
- start and end time is a string but in validator it is datetime
