# VR_Health

Based on Team 17's specifications.

## Description

- VR_Health is a Virtual Reality platform that offers a range of immersive and interactive experiences aimed at helping users manage various health conditions. The platform utilizes the latest VR technology to provide a personalized and engaging experience that is both informative and fun. 

- VR_Health provides users with access to a variety of features such as virtual support groups, guided meditations/yoga sessions, and interactive meetings that are designed to promote social interactions.

## Assumptions

- Since the description of the product in the SRS document is really vague and contains a lot of stuff. We decided to focus on guided meditation/yoga and round table social meetings for this assignment part.

- We assume that each of activities are happening in the same scene, but are present as nested scenes of the main scene.
