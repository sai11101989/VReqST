Our VR game tries to provide a realistic cricket experience as a batsman.
As per the requirements we have chosen 4 scenes which are practice nets, stadium, main menu and scoreboard. We have separate json file each scene.
We have chosen our bat,ball,pitch,field,bowler,fielder,wickets and scoreboard as articles. These are the objects used in specific scene and have different propeties based on their requirements.
We have defined action responses which are bat-ball, bat-wicket,ball-wicket,ball-fielder,ball-boundary,ball-umpire and bat-non_striker. These can be natural or custom based on the requirements.
We have defined custom behviours like ballmovement,fourscore,sixscore,runscore,runout,catchout and bowled. These are the behaviours of the articles when actions happen like hit, catch, detach etc.
We have mentioned the timelines for the ball hitting the bat, the wickets and player taking the runs. These have their own json files as well.
