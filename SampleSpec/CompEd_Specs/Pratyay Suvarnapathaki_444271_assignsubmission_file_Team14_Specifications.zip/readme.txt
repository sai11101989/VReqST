Virtual Reality Campus Tour

PRODUCT DESCRIPTION (LESS THAN 100 WORDS)
This tour provides a virtual environment where users can explore a campus in a 3D setting. The software is designed to help prospective students, parents, and others interested in the university experience the campus environment from the comfort of their own homes. By providing this virtual tour, students can make better-informed decisions about which university they would like to attend.

SRS SUMMARY - FUNCTIONAL REQUIREMENTS THAT PERTAIN TO VR
1. Campus Navigation: Move about in the environment
2. Building Information: Users can access building info by clicking on a 'notice board' outside it. 
   Examples: hostel timings and rules at the dorms, mess menu outside mess etc. 
3. Interaction with objects: User pushes doors / dips hand in realistic water / touches trees, etc. [custom objects, nothing pre-specified]
4. Virtual Tour Guide: Guided tour on a pre-configured path showcasing the campus.

SUPPLEMENTARY FILES
Apart from the 5 jsons we are required to submit, we have also included our source code for custom behavior and recordings of us verifying all our files using the VReqST GUI. Here is the link to it: https://drive.google.com/drive/folders/1jp3REnllSBWYND1TWIwag_PueJoYwg28?usp=share_link