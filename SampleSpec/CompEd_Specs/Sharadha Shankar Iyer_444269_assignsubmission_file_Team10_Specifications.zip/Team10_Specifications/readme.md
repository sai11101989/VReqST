# VR Shopping

## Team
- Sravanthi - 2019101101
- Sharadha - 2019101048
- Hasvitha - 2019101030
- Aasish Raj - 2020101049
- Harshavardhan - 2020101106

## Gist
This zip contains the 5 json files that we have written for the SRS submitted by team 28.
The VR experience is shopping for items in a store. 
Here, we have the user interact with a shopping cart that they can "push" around the store
They can also pick items off the shelf in the store, and observe or add to cart. The items can later be removed as well