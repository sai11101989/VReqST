### Introduction:
The VR product we have in this SRS is a virtual reality fitness app that can be used with a
VR headset. It would provide users with a range of interactive workouts and training
programs designed to help them achieve their fitness goals. 

This product provides user various environments to workout like beach, mountain, and forest. 
One can also connect with their fellow users to workout together with a facility to view scoreboard of their workout.
One can also recieve personalized coaching or training.
There various workout types available like yoga, cardio, and strength for this VR app.
By going through this SRS we have found that there are no interactive objects for the user.
The user can only view the environment choosen and workout without any interaction.

So we have decided to add two new workout programs:
1. Flow 
2. Combat

These are inspired from the fitness VR apps like supernatural VR fitness and fitxr VR app.
The above workout programs increase the interactive abilities of the product and helps in engaging the user.
