1.Rules of the VR game
a.The player begins the ride on the railtrack while sitting inside the railcart.The railcart has an intial velocity.
b.The player can steer the railcart (to change tracks) using the steering wheel.
c.The player can press the jump button (present on railcart controller) to make the railcart jump so as to avoid obstacles on the railtrack.
d.The player can perform a grab action on the bonus coins by extending their arms and grabbing the virtual coins.On grabbing a coin 5 points are added to the player's score.
e.The player can perform a duck action by actually ducking , to avoid overhead obstacles(eg.birds).
f.If the railcart hits a rock or if the player hits an overhead bird the game is over.
g.If the player succesfully reaches the end of the railtrack the game is completed and the score is updated with the total distance travelled

2.Sensors placed on the user(human) 
a.Head-mounted display (HMD)sensors will be used to identify ducking motion.
b.Motion sensors will be used to identify grabbing motion.

3.scene
a.We have one scene.It consists of interactive and non-interactive components.The railtrack and scenary is a non-interactive dynamic components.
b.The player has a 360 degree view.

4.article
a.We have 8 articles.They are- rock,bird,railcart, 5 bonus coins.

5.actionresponse
a.We have defined 4 action responses.They are used to describe the following actions.
-player grabs coins
-player steers railcart
-player makes railcart jump using controller
-player ducks

6.custom
a.We have defined logics for the following functions
-Game is completed
-Game is over 
-Score for player is updated
b.We have defined custom.json based on the template provided. However, the json file that we downloaded from VReqST tool had a different format. Please find below the custom json file that was downloaded from VReqST tool:
{"objects_used":["Coin_1","Coin_2","Coin_3","Coin_4","Coin_5","Rail_Cart","Obstacle_Bird","Obstacle_Rock","Coin_1","Coin_2","Coin_3","Coin_4","Coin_5","Rail_Cart","Obstacle_Bird","Obstacle_Rock","player_grabcoin","player_steercart","player_jumpRailCart","player_ducksBirds","Coin_1","Coin_2","Coin_3","Coin_4","Coin_5","Rail_Cart","Obstacle_Bird","Obstacle_Rock","player_grabcoin","player_steercart","player_jumpRailCart","player_ducksBirds"],"rules":[{"rulename":"Game play", "description":"Score update","logic": "SWYjPHBsYXllcl9ncmFiY29pbiA9PSB0cnVlPiM6PHBvaW50Kz01IHBsYXllcl9ncmFiY29pbj1mYWxzZT4hDQpJZiM8Z2FtZW92ZXJ8fCAkZ2FtZWNvbXBsZXRlPiM6PHBvaW50Kz0kZGlzdGFuY2Vjb3ZlcmVkPiE="}
,{"rulename":"Game Over", "description":"Condition for game over","logic": "SWYjUmFpbF9DYXJ0IDxoaXRzYmlyZD4jOjxnYW1lb3Zlcj4hDQpJZiNSYWlsX0NhcnQgPGhpdHNyb2NrPiM6PGdhbWVvdmVyPiE="}
,{"rulename":"Game Complete", "description":"Completion of game","logic": "DQpJZiM8ZGlzdGFuY2Vjb3ZlcmVkPT10b3RhbHRyYWNrZGlzdGFuY2U+Izo8Z2FtZWNvbXBsZXRlPiE="}
]}

7.timeline
a.We have described 4 cases
-animate triggered asyn: This type of events occurs for bonus coins, obstacles, score updation.
-animate triggered syn: This type of events occurs for railcart.    
-animate non-triggered asyn:
-animate non-triggered syn:  This type of events occurs for railtrack

b.We were unable to validate this json on VReqST due to following errors
"AsyncObjList" is a mandatory field! Please add the field with type object
"starttime" has an invalid type of 'string'. Expected type of datetime
"starttime" has an invalid type of 'string'. Expected type of datetime
"endtime" has an invalid type of 'string'. Expected type of datetime
"endtime" has an invalid type of 'string'. Expected type of datetime

We have followed the given sample template for the json.

