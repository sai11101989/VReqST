The requirements specified for the VR game is similar to a PUBG game with a VR functionality.
We added different objects ike sun, gun, bullets, zombie, tree, hill etc.

The user shoots the zombies with guns.
Guns can be found on the ground at some locations.
Guns they are loaded with infinite ammo.

The user can move freely in the map and shoot the zombies.