 VhorroR

1. scene.json :In scene.json file we have created two scenes according to the requirement.First scene name is 'Abandoned Hospital' in this scene we are showing an abandoned horror hospital having nurses,doctors and patients.
Similarly second scene is 'Graveyard' this horror scene has 'cemetery workers' in the scene.

2. article.json :In the horror house we have articles i.e. objects as door, ghost, zombie, skeleton, torch and trap.
These objects are used to scare the user while experiencing horror house.

3. actres.json :In actres.json varios objects(camera,torch,door,ghost,skull/skeleton,zombies,traps) and how they interact with each other showing the action taken and the response to the action for various different cases.

4. custom.json :Here we have shown the logic in base 64 encoding of the various cases or actions we have taken to scare the user of how the user reacts to it.It also shows responses to various traps and scary actions taken.

5. timeline.json: This is a json for animating scenes with different synchronization types and routines. The objects in the scene are of two types which are synchronized and asynchronized and are triggered or not triggered. In the scene, door is triggered synchronously based on a trigger. ghost, zombie and skeleton are not triggered synchronously. Similarly torch is triggered asynchronously which flashes on user's command. Routine is the timeline of actions in the scene and order is the sequence of the items in routine.
