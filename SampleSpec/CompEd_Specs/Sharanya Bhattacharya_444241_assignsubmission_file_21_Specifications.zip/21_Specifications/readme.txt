This project Amusement Park Arcade Virtual Reality Roller Coaster VR Simulator Game
Machine gives customers an authentic immersive roller coaster ride experience which is 
additionally gamified. This VR Product is necessitates the use of 9D VR Egg Chairs along 
with VR Headsets. This game can also be played/experienced in multiplayer mode, adding to
the fun of the overall experience. The VR game also has the added advantage of being safer
than an actual roller coaster.