Readme : 
custom.json
Rule 1 : shotrule
    Objects used : bat, ball
    Actions used : hitball
    Logic : if bat hits ball, increment run count by 1

Rule 2 : wicketfallrule
    Objects used : bat, ball, wickets
    Actions used : hitwicket, bowled
    Logic : if bat hits wickets or ball hits wicket, then bowled

Rule 3 : scoreupdaterule
    Objects used : 
    Actions used : bowled
    Logic : if bowled, increment wicket_count by 1s

scene.json
The json is filled according to the batter's view of the game

article.json
We found out bat,ball,wickets,scoreboard are the objects in the game

actionresponse.json
The objects we listed are bat_response,ball_response,scoreboard
